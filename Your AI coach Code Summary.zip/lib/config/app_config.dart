// app_config.dart
// Konfigurasi aplikasi — API key dibaca dari file .env (via flutter_dotenv)
// JANGAN hardcode API key langsung di sini untuk production.
// File .env sudah ditambahkan ke .gitignore.

import 'package:flutter_dotenv/flutter_dotenv.dart';

class AppConfig {
  // Groq AI API Key — dibaca dari .env saat runtime
  static String get groqApiKey =>
      dotenv.env['GROQ_API_KEY'] ?? '';

  static const String groqBaseUrl =
      'https://api.groq.com/openai/v1/chat/completions';

  // Model yang digunakan
  static const String groqModel = 'llama-3.3-70b-versatile';
  static const String groqVisionModel = 'meta-llama/llama-4-scout-17b-16e-instruct';

  // Timeout untuk request AI (dalam detik)
  static const int requestTimeoutSeconds = 30;
}
